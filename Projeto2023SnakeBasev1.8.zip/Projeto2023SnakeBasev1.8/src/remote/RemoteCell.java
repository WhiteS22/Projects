package remote;

public class RemoteCell {

}
