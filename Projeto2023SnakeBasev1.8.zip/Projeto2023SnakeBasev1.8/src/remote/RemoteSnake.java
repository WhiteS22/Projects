package remote;

public class RemoteSnake {

}
