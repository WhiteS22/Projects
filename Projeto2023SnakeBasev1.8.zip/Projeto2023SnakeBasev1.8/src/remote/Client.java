package remote;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;

import environment.LocalBoard;
import game.HumanSnake;
import game.Server;
import gui.BoardComponent;
import gui.SnakeGui;


public class Client extends Thread{
	private ObjectInputStream in;
	private PrintWriter out;
	private Socket socket;
	protected RemoteBoard remoteBoard;
	private SnakeGui boardGuiClient;
	
	
	public Client() {
		remoteBoard = new RemoteBoard();

		SnakeGui game = new SnakeGui(remoteBoard,600,0);
		game.init();
	}
	public static void main(String[] args) {
		new Client().runClient();
	}

	public void runClient() {
		try {
			System.out.println("vou fzr connectToServer, ReceiveBoard,start(), sendUsedKey()");
			connectToServer();
			new ReceiveBoard().start();
			sendUsedKey();
			System.out.println("fiz connectToServer, ReceiveBoard,start(), sendUsedKey()");
			
		} catch (IOException e) {// ERRO...
			System.out.println("ERROUUUU");
		} finally {//a fechar...
			try {
				socket.close();
			} catch (IOException e) {//... 
			}
		}
	}
	
	private void sendUsedKey() {
		System.out.println("SendUsedKey started");
		while (true) {
			if (remoteBoard instanceof RemoteBoard) {                   //boardGuiClient.getBoard() instanceof RemoteBoard --> board instanceof RemoteBoard       
				//RemoteBoard remoteBoard = board;
				String nextCell = remoteBoard.getNextCell();
				System.out.println(nextCell);
				System.out.println("vou enviar nextCell");
				out.println(nextCell);
				System.out.println("enviei nextCell");
				try {
					System.out.println("Vou dormir 500");
					sleep(500);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	void connectToServer() throws IOException {
		InetAddress endereco = InetAddress.getByName(null);
		System.out.println("Endereco:" + endereco);
		socket = new Socket(endereco, Server.PORTO);
		System.out.println("Socket:" + socket);
		in = new ObjectInputStream (socket.getInputStream());
		out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
		System.out.println("in and out instaciados");
	}
	

//	public class SendUsedKey extends Thread {
//		@Override
//		public void run() {
//			System.out.println("SendUsedKey started");
//			while (true) {
//				if (board instanceof RemoteBoard) {                   //boardGuiClient.getBoard() instanceof RemoteBoard --> board instanceof RemoteBoard       
//					//RemoteBoard remoteBoard = board;
//					String nextCell = board.getNextCell();
//					System.out.println(nextCell);
//					out.println(nextCell);
//					try {
//						System.out.println("Vou dormir 500");
//						sleep(500);
//					} catch (InterruptedException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//				}
//			}
//		}
//	}
	
	public class ReceiveBoard extends Thread {
		@Override
		public void run() {
			try {
				sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			while (true) {
				try {
					try {
						sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Object msg = in.readObject();
					if (msg instanceof RemoteBoard) {
						System.out.println("if (msg instanceof RemoteBoard)... --> entrou aqui");
						remoteBoard = (RemoteBoard)msg;
//						boardGuiClient.setBoard(board);
//						boardGuiClient.repaint();
					}
				} catch (ClassNotFoundException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					try {
						in.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				remoteBoard.setChanged();
			}
		}
	}
}
