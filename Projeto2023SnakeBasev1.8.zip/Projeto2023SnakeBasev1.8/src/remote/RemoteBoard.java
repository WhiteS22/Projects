package remote;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.LinkedList;

import environment.LocalBoard;
import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import game.Goal;
import game.Obstacle;
import game.Snake;

/**
 * Remote representation of the game, no local threads involved. Game state will
 * be changed when updated info is received from Srver. Only for part II of the
 * project.
 * 
 * @author luismota
 *
 */
public class RemoteBoard extends Board implements Serializable{
	private String nextCell;
	
	//protected LinkedList<RemoteSnake> snakes = new LinkedList<RemoteSnake>();
	//protected LinkedList<Obstacle> obstacles= new LinkedList<Obstacle>();
	//protected LinkedList<Cell> cells = new LinkedList<Cell>();
	private Cell[][] cells;
	
	public RemoteBoard() {
		cells = new Cell[NUM_COLUMNS][NUM_ROWS];
		for (int x = 0; x < NUM_COLUMNS; x++) {
			for (int y = 0; y < NUM_ROWS; y++) {
				cells[x][y] = new Cell(new BoardPosition(x, y));
			}
		}
	}

	@Override
	public void handleKeyPress(int e) {
		switch (e) {
		case KeyEvent.VK_LEFT:
			nextCell = "LEFT";
			break;
		case KeyEvent.VK_RIGHT:
			nextCell = "RIGHT";
			break;
		case KeyEvent.VK_UP:
			nextCell = "UP";
			break;
		case KeyEvent.VK_DOWN:
			nextCell = "DOWN";
			break;
		}
	}

	@Override
	public void handleKeyRelease() {
		// TODO
	}

	@Override
	public void init() {
//        for(Snake s:snakes)
//            s.start();
//        // TODO: launch other threads
//        setChanged();
    }
	
	public String getNextCell() {
		return this.nextCell;
	}
	public void setNextCell(String nextCell) {
		this.nextCell = nextCell;
	}
	
	public void updateCells(Board board) {
		for (int x = 0; x < board.NUM_COLUMNS; x++) {
			for (int y = 0; y < board.NUM_ROWS; y++) {
				//board.getCell() = new Cell(new BoardPosition(x, y));
				if(board.getCell(new BoardPosition(x,y)).getOcuppyingSnake()!=null) {
					this.getCells(new BoardPosition(x,y)).setSnakeRemote(
						board.getCell(new BoardPosition(x,y)).getOcuppyingSnake());
				} if(board.getCell(new BoardPosition(x,y)).getGameElement()!=null) {
					this.getCells(new BoardPosition(x,y)).setGameElementRemote(
						board.getCell(new BoardPosition(x,y)).getGameElement());
				}
			}
		}
	}
	
	public Cell getCells(BoardPosition cellCoord) {
		return this.cells[cellCoord.x][cellCoord.y];
	}

	public Cell[][] getCellmap(){
		return cells;
	}
}
