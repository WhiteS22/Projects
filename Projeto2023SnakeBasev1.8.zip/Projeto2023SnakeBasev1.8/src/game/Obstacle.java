package game;

import java.io.Serializable;

import environment.Board;
import environment.Cell;
import environment.LocalBoard;

public class Obstacle extends GameElement implements Serializable {
	
	
	private static final int NUM_MOVES=3;
	private static final int OBSTACLE_MOVE_INTERVAL = 400;
	private int remainingMoves=NUM_MOVES;
	private transient Board board;
	private Cell cell;
	
	public Obstacle(Board board) {
		super();
		this.board = board;
	}
	
	public int getRemainingMoves() {
		return remainingMoves;
	}
	
	public void decreaseRemainingMoves() {
		remainingMoves--;
	}
	
	public void changeCell(Cell cell) {
		this.cell = cell;
	}
	
	public Cell getCell() {
		return cell;
	}
	
	public int getSleepInterval() {
        return OBSTACLE_MOVE_INTERVAL;
    }

}
