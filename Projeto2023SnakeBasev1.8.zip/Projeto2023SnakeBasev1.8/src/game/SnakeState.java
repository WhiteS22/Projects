package game;

import java.io.Serializable;
import java.util.LinkedList;

import environment.Cell;

public class SnakeState implements Serializable{
	
	protected LinkedList<CellState> cells = new LinkedList<CellState>();
	protected int size = 5;
	private int id;
	
	public SnakeState(LinkedList<Cell> cells, int size, int id) {
		//this.cells = cells;
		this.size = size;
		this.id = id;
	}
	
	private void makeCellsStateList(LinkedList<Cell> cells) {
		
		for(Cell c: cells) {
			//this.cells.add(c)
		}
	}
}
