package game;

import java.io.Serializable;

public abstract class GameElement implements Serializable{

}
