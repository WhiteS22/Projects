package game;

import java.io.Serializable;

import environment.Board;
import environment.Cell;
 /** Class for a remote snake, controlled by a human 
  
@author luismota
**/
public class HumanSnake extends Snake implements Serializable {
	private String nextCell;

    public HumanSnake(int id,Board board) {
        super(id,board);
    }

    @Override
    public void run() {
    	doInitialPositioning();
		try {
			sleep(getBoard().PLAYER_PLAY_INTERVAL);
			remoteMove();
			getBoard().setChanged();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	public void remoteMove() throws InterruptedException {
		if (nextCell != null) {			
			move(stringToCell(nextCell)); 
		}
	}
	
	public Cell stringToCell(String nextCell){
		Cell cell = new Cell(null);		
			switch(nextCell) {
			case "LEFT":
				cell = getBoard().getCell(this.getCells().getLast().getPosition().getCellLeft());				
			case "RIGHT":
				cell = getBoard().getCell(this.getCells().getLast().getPosition().getCellRight());
			case "UP":
				cell = getBoard().getCell(this.getCells().getLast().getPosition().getCellAbove());
			case "DOWN":
				cell = getBoard().getCell(this.getCells().getLast().getPosition().getCellBelow());
			}
			return cell;
	}

	public String getNextCell() {
		return nextCell;
	}

	public void setNextCell(String nextCell) {
		this.nextCell = nextCell;
	}
}