package game;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.LinkedList;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import remote.RemoteBoard;

public class ClientHandler implements Runnable {
	private Socket client;
	private BufferedReader in;
	private ObjectOutputStream out;
	private Board board;
	
	public ClientHandler(Socket clientSocket, Board board) throws IOException {
		this.client = clientSocket;
		this.board = board;
		doConnections(clientSocket);
	}
	
	@Override
	public void run() {
		try {
			out = new ObjectOutputStream(client.getOutputStream());
			System.out.println("out instanciado------------------------------------------------------------");
			new SendBoard(out, board).start();
			serve();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	void doConnections(Socket socket) throws IOException {
		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		out = new ObjectOutputStream(socket.getOutputStream());
	}

	private void serve() throws IOException {
		try {
			HumanSnake hSnake = new HumanSnake(board.getNextId(), board);

			board.addSnake(hSnake);
			hSnake.start();

			while (true) {
				try {
					Thread.sleep(400);					//dorme -100 do q o q dorme no cliente;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}        
				String nextCell = in.readLine();
				System.out.println(nextCell);
				hSnake.setNextCell(nextCell);
			}
		} finally {
			in.close();
		}
	}
	
	public class SendBoard extends Thread {
		private ObjectOutputStream out;
		private RemoteBoard remoteBoard;
		private Cell[][] cells;
		
		public SendBoard(ObjectOutputStream out, Board board) {
			this.out = out;
			RemoteBoard b = new RemoteBoard();
			b.updateCells(board);
			this.remoteBoard = b;
		}
		
		@Override
		public void run() {
			try {
				while(true) {
					makeBoard();
					
					System.out.println("Vou enviar objecto--------------------------");
					cells = remoteBoard.getCellmap();
					
					//out.writeObject(remoteBoard);
					out.writeObject(cells);
					System.out.println("Vou dormir 1000");
					sleep(1000);
					
				}
			} catch (InterruptedException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					out.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		
//		private LinkedList<Cell> makeCellList(RemoteBoard remoteboard){
//			remoteboard.get
//		}

		private void makeBoard() {
			for (int x = 0; x < board.NUM_COLUMNS; x++) {
				for (int y = 0; y < board.NUM_ROWS; y++) {
					//board.getCell() = new Cell(new BoardPosition(x, y));
					if(board.getCell(new BoardPosition(x,y)).getOcuppyingSnake()!=null) {
						remoteBoard.getCell(new BoardPosition(x,y)).setSnakeRemote(
							board.getCell(new BoardPosition(x,y)).getOcuppyingSnake());
					} if(board.getCell(new BoardPosition(x,y)).getGameElement()!=null) {
						remoteBoard.getCell(new BoardPosition(x,y)).setGameElementRemote(
							board.getCell(new BoardPosition(x,y)).getGameElement());
					}
				}
			}
		}
		

		
	}
}
