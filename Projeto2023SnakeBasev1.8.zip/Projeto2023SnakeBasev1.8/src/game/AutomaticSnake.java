package game;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.swing.text.Position;

import environment.LocalBoard;
import gui.SnakeGui;
import environment.Cell;
import environment.Board;
import environment.BoardPosition;

public class AutomaticSnake extends Snake {
	List<BoardPosition> notToGo = new ArrayList<>();
	
	public AutomaticSnake(int id, LocalBoard board) {
		super(id,board);

	}

	@Override
	public void run() {
		doInitialPositioning();
		System.err.println("initial size:"+cells.size());
		try {
			sleep(1000);										//alterar para 10000 de novo
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
//		try {
//			cells.getLast().request(this);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block          //Codigo base do stor nao fazia sentido
//			e.printStackTrace();
//		}
		//TODO: automatic movement
		while(true) {
		try {
			sleep(getBoard().PLAYER_PLAY_INTERVAL);
			automaticMovement();
			getBoard().setChanged();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Thread terminou");
			break;
		}
	}
}	
	protected void automaticMovement() {
		List<BoardPosition> neighbors = getBoard().getNeighboringPositions(getCells().getLast());
		double lessDistance = 100;
		Cell optimalNeighbor = null;
		for (BoardPosition neighborPos : neighbors) {  //Percorre as celulas vizinhas
			if (!(this.getPath().contains(neighborPos)) && !notToGo.contains(neighborPos)) {
				//Verifica se tem cobra a propria cobra ou se esta na lista notToGo, senao continua
				double temporaryDistance = neighborPos.distanceTo(getBoard().getGoalPosition());
				if (temporaryDistance < lessDistance) {		//Guarda a distancia mais pequena
					lessDistance = temporaryDistance;
					optimalNeighbor = getBoard().getCell(neighborPos);
				}
			}			
		}
		try {
			move(optimalNeighbor);
			neighbors.clear();
		} catch (InterruptedException e) {
			notToGo.add(optimalNeighbor.getPosition());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}