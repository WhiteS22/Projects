package game;

import java.util.List;

import environment.BoardPosition;
import environment.LocalBoard;

public class ObstacleMover extends Thread {
	private Obstacle obstacle;
	private LocalBoard board;
	
	public ObstacleMover(Obstacle obstacle, LocalBoard board) {
		super();
		this.obstacle = obstacle;
		this.board = board;
	}

	@Override
	public void run() {
		// TODO
		System.out.println("obstacleMover iniciado");
		while(obstacle.getRemainingMoves()>0){
			System.out.println("enetering WHILE");
			obstacle.decreaseRemainingMoves();
			moveObstacle();
			System.out.println("-------------------------------------mexendo");
			try {
				sleep(obstacle.getSleepInterval());
				System.out.println("------------------------------------esperando");
			} catch (InterruptedException e) {
				System.out.println("bug1");
				e.printStackTrace();
			}
			board.setChanged();
			System.out.println("bug2");
		}
		
	}
	
	private void moveObstacle() {
		
		List<BoardPosition> neighborsPositions = null;
		int random;
		BoardPosition pos = null;
		System.out.println("1");
		System.out.println(obstacle.getCell().getPosition().x);
		System.out.println("2");
			neighborsPositions = board.getNeighboringPositions(obstacle.getCell());
			
			while(pos == null) {						//para evitar q o pos fique igual a null caso um dos vizinhos esteja outOfBounds
				random = (int)(Math.random()*4);
				switch(random) {
					case (int) 0 :
						pos = neighborsPositions.get(0);
						break;
					case (int) 1 :
						pos = neighborsPositions.get(1);
						break;
					case (int) 2 :
						pos = neighborsPositions.get(2);
						break;
					case (int) 3:
						pos = neighborsPositions.get(3);
						break;
				}
			}
			
			//board.addGameElement(obstacle);
			BoardPosition prevPos = obstacle.getCell().getPosition();
			obstacle.changeCell(board.getCell(pos));
			board.getCell(pos).setGameElement(obstacle);
			board.getCell(prevPos).removeObstacle();
			
	}
}
