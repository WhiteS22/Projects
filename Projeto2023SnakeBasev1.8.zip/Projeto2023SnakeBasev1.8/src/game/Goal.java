package game;

import java.io.Serializable;

import environment.Board;

public class Goal extends GameElement  implements Serializable{
	private int value=1;
	private transient Board board;
	public static final int MAX_VALUE=9;
	
	public Goal( Board board2) {
		this.board = board2;
	}
	
	public int getValue() {
		return value;
	}
	
	public void setValue(int value2) {
		this.value = value2;
	}
	
	public void captureGoal() {			
		if(value==MAX_VALUE) {
			board.endGame();
		}
		value++;
		board.addGameElement(this);		
	}
}
