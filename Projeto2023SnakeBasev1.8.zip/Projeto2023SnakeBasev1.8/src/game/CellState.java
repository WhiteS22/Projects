package game;

import java.io.Serializable;

public class CellState implements Serializable {
	private int x;
	private int y;
	private SnakeState occupyingSnake;
	
}
