package environment;

import java.io.Serializable;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.sound.midi.SysexMessage;

import game.GameElement;
import game.Goal;
import game.Obstacle;
import game.Snake;
import game.AutomaticSnake;
/** Main class for game representation. 
 * 
 * @author luismota
 *
 */
public class Cell implements Serializable{
	private BoardPosition position;
	private Snake ocuppyingSnake = null;
	private GameElement gameElement=null;
	private transient Lock lock = new ReentrantLock();
	private transient Condition waitingPlayer = lock.newCondition();
	private transient Condition waitingObstacle = lock.newCondition();
	
	public GameElement getGameElement() {
		return gameElement;
	}


	public Cell(BoardPosition position) {
		super();
		this.position = position;
	}

	public BoardPosition getPosition() {
		return position;
	}

	public void request(Snake snake) throws InterruptedException {
		//TODO coordination and mutual exclusion  	
		lock.lock();
		try {
			System.out.println("Cheguei request1");			
			while(isOcupiedBySnake()) {		//Meter a thread em espera
				waitingPlayer.await();	              
				System.out.println("Cheguei request2");				
			}
			while(isOcupiedByObstacle()) {		//Meter a thread em espera
				waitingObstacle.await();	              
				System.out.println("Cheguei request2");				
			}
			ocuppyingSnake=snake;			
			if(isOcupiedByGoal()) {
				snake.eatGoal(this.getGoal());
			}
		} finally {
		System.out.println("Cheguei request3");						
		lock.unlock();
		}
	}

	public void release() {
		//TODO
		lock.lock();
		try {
		ocuppyingSnake=null;												
		System.out.println("Cheguei release1");
		waitingPlayer.signalAll();								
		System.out.println("Cheguei release2");
		} finally {
			lock.unlock();
		}
	}

	public boolean isOcupiedBySnake() {
		return ocuppyingSnake!=null;
	}
	
	public boolean isOcupiedByObstacle() {
		return (gameElement!=null && gameElement instanceof Obstacle);
	}
	
	public void setGameElement(GameElement gameElement) {
		lock.lock();
		try {
			if (!isOcupied() && !isOcupiedByGoal()) {
				this.gameElement = gameElement;
			}
		} finally {
			lock.unlock();
		}
	}

	public boolean isOcupied() {
		return isOcupiedBySnake() || (gameElement!=null && gameElement instanceof Obstacle);
	}
	
	


	public Snake getOcuppyingSnake() {
		return ocuppyingSnake;
	}

	public void removeGoal() {
		if(gameElement instanceof Goal)
			gameElement = null;
	}
	
	public void removeObstacle() {
	//TODO
		lock.lock();
		try {
			gameElement = null;
			waitingObstacle.signal();
		} finally {
			lock.unlock();
		}
		
	}


	public Goal getGoal() {
		return (Goal)gameElement;
	}


	public boolean isOcupiedByGoal() {
		return (gameElement!=null && gameElement instanceof Goal);
	}
	
	public void setSnakeRemote(Snake snake) {
		this.ocuppyingSnake=snake;
	}
	
	public void setGameElementRemote(GameElement element) {
		this.gameElement=element;
	}
}